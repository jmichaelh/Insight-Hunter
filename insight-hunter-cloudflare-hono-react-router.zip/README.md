# Insight Hunter — Cloudflare Workers + Hono + React Router (Vite)

All-in-Cloudflare fullstack starter:
- **Workers** runtime with **Hono** for APIs
- **React Router** app built by **Vite**
- Static assets served by the Worker
- **JWT auth** (username/password → token)
- **Reports History** persisted in **KV**

## 1) Prereqs

- Node 20+ (or 18+ with latest npm)
- Cloudflare account
- `npm i -g wrangler`

## 2) One-time Cloudflare setup

```bash
# Login once
wrangler login

# Create KV for reports
wrangler kv namespace create insight_hunter_reports
# Copy the "id" into wrangler.toml replacing REPLACE_WITH_KV_ID
```

Optionally set secrets (recommended for prod):

```bash
wrangler secret put JWT_SECRET
wrangler secret put USERNAME
wrangler secret put PASSWORD
```

## 3) Install & run locally

```bash
npm install
# Run API (8787) + Vite client (5173) together
npm run dev
# Visit http://localhost:5173
# Login with admin / password (defaults configurable in wrangler.toml or secrets)
```

Vite proxies `/api/*` to the Worker during dev.

## 4) Build & deploy

```bash
# Build client to ./dist then deploy Worker serving assets + /api
npm run build
```

Or preview against Cloudflare:

```bash
npm run preview
```

## 5) API

- `POST /api/auth/login` → `{ token }`
- `GET /api/reports` (Bearer) → `{ reports: [] }`
- `POST /api/reports` (Bearer) body: `{ title, summary, payload }`

## 6) Notes

- Static files are served from `dist` via `assets` binding in `wrangler.toml`.
- SPA fallback is handled by the Worker (unknown routes → `index.html`).
- Storage uses KV (`INSIGHT_KV`) for simple persistence. Migrate to D1 or Durable Objects if you need relational queries or transactions.

## 7) Cloudflare Access (optional)

If you prefer Cloudflare Access instead of JWT, validate the Access JWT in the Worker by checking the `Cf-Access-Jwt-Assertion` header against your Access team domain JWKS. Keep JWT here as default for simplicity.

---

**Structure**

```
src/
  worker.ts               # Hono app on Workers (APIs + static fallback)
  client/
    main.tsx              # React Router entry
    routes/
      Root.tsx
      Login.tsx
      Protected.tsx
      Dashboard.tsx
      Reports.tsx
index.html                # Vite mount
wrangler.toml             # Worker config + assets + KV binding
vite.config.ts            # Dev proxy + build output
```
