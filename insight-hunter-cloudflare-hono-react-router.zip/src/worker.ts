import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { jwtVerify, SignJWT } from 'jose'

type Bindings = {
  ASSETS: Fetcher
  INSIGHT_KV: KVNamespace
  JWT_SECRET: string
  USERNAME: string
  PASSWORD: string
}

const app = new Hono<{ Bindings: Bindings; Variables: { user?: string } }>()

app.use('/api/*', cors())

// Auth: username/password -> JWT
app.post('/api/auth/login', async (c) => {
  const body = await c.req.json<{ username: string; password: string }>()
  const u = c.env.USERNAME || 'admin'
  const p = c.env.PASSWORD || 'password'
  if (body.username !== u || body.password !== p) {
    return c.json({ error: 'invalid_credentials' }, 401)
  }
  const secret = new TextEncoder().encode(c.env.JWT_SECRET || 'dev-secret')
  const token = await new SignJWT({ sub: body.username })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('7d')
    .sign(secret)
  return c.json({ token })
})

async function requireAuth(c: any, next: any) {
  const auth = c.req.header('Authorization') || ''
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : ''
  if (!token) return c.json({ error: 'missing_token' }, 401)
  try {
    const secret = new TextEncoder().encode(c.env.JWT_SECRET || 'dev-secret')
    const { payload } = await jwtVerify(token, secret)
    c.set('user', String(payload.sub || 'user'))
    await next()
  } catch {
    return c.json({ error: 'invalid_token' }, 401)
  }
}

// Reports API
app.get('/api/reports', requireAuth, async (c) => {
  const list = await c.env.INSIGHT_KV.list({ prefix: 'report:' })
  const reports: any[] = []
  for (const k of list.keys) {
    const r = await c.env.INSIGHT_KV.get(k.name, 'json' as any)
    if (r) reports.push(r)
  }
  // sort by createdAt desc
  reports.sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))
  return c.json({ reports })
})

app.post('/api/reports', requireAuth, async (c) => {
  const body = await c.req.json<any>()
  const id = crypto.randomUUID()
  const report = {
    id,
    createdAt: new Date().toISOString(),
    title: body.title ?? 'Untitled Report',
    summary: body.summary ?? '',
    payload: body.payload ?? {}
  }
  await c.env.INSIGHT_KV.put(`report:${id}`, JSON.stringify(report))
  return c.json(report, 201)
})

app.get('/api/health', (c) => c.json({ ok: true }))

// Static file / SPA fallback from Vite build output
app.all('*', async (c) => {
  // Try to serve built assets
  const assetRes = await c.env.ASSETS.fetch(c.req.raw)
  if (assetRes.status !== 404) return assetRes

  // SPA fallback -> index.html
  const url = new URL(c.req.url)
  const req = new Request(new URL('/index.html', url.origin), { method: 'GET' })
  return c.env.ASSETS.fetch(req)
})

export default app
