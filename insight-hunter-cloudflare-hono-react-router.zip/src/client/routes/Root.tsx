import React from 'react'
import { Link, Outlet, useLocation } from 'react-router-dom'

export default function Root() {
  const loc = useLocation()
  const token = localStorage.getItem('ih_jwt')

  function signOut() {
    localStorage.removeItem('ih_jwt')
    window.location.href = '/login'
  }

  return (
    <div style={{ fontFamily: 'system-ui, Arial, sans-serif', margin: 24 }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1 style={{ margin: 0 }}>Insight Hunter</h1>
        <nav style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <Link to="/">Dashboard</Link>
          <Link to="/reports">Reports</Link>
          {!token ? <Link to="/login" state={{ from: loc.pathname }}>Login</Link> :
            <button onClick={signOut}>Sign out</button>
          }
        </nav>
      </header>
      <main style={{ marginTop: 24 }}>
        <Outlet />
      </main>
      <footer style={{ marginTop: 48, fontSize: 12, color: '#666' }}>Cloudflare Workers + Hono + React Router</footer>
    </div>
  )
}
