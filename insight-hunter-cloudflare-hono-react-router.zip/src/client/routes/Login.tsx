import React, { useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'

export default function Login() {
  const [username, setUsername] = useState('admin')
  const [password, setPassword] = useState('password')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const nav = useNavigate()
  const loc = useLocation() as any

  async function submit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError(null)
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'login_failed')
      localStorage.setItem('ih_jwt', data.token)
      nav(loc?.state?.from || '/')
    } catch (err: any) {
      setError(String(err.message || 'login_failed'))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ maxWidth: 360 }}>
      <h2>Login</h2>
      <form onSubmit={submit}>
        <div style={{ display: 'grid', gap: 12 }}>
          <label>
            <div>Username</div>
            <input value={username} onChange={(e) => setUsername(e.target.value)} required />
          </label>
          <label>
            <div>Password</div>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} required />
          </label>
          <button disabled={loading} type="submit">{loading ? 'Signing in...' : 'Sign in'}</button>
          {error && <div style={{ color: 'crimson' }}>{error}</div>}
        </div>
      </form>
      <p style={{ marginTop: 12, fontSize: 13, color: '#666' }}>Defaults are admin / password. Configure in wrangler.toml</p>
    </div>
  )
}
