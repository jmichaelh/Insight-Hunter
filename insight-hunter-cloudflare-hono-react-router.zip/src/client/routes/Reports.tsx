import React, { useEffect, useState } from 'react'

type Report = {
  id: string
  createdAt: string
  title: string
  summary: string
  payload: any
}

export default function Reports() {
  const [reports, setReports] = useState<Report[]>([])
  const [title, setTitle] = useState('Demo Report')
  const [summary, setSummary] = useState('First test')
  const [loading, setLoading] = useState(false)

  async function load() {
    const token = localStorage.getItem('ih_jwt') || ''
    const res = await fetch('/api/reports', {
      headers: { Authorization: `Bearer ${token}` }
    })
    const data = await res.json()
    setReports(data.reports || [])
  }

  async function create() {
    setLoading(true)
    try {
      const token = localStorage.getItem('ih_jwt') || ''
      const res = await fetch('/api/reports', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`
        },
        body: JSON.stringify({
          title,
          summary,
          payload: { example: true }
        })
      })
      if (res.ok) await load()
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [])

  return (
    <section>
      <h2>Reports History</h2>
      <div style={{ display: 'flex', gap: 12, marginBottom: 16 }}>
        <input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} />
        <input placeholder="Summary" value={summary} onChange={(e) => setSummary(e.target.value)} />
        <button onClick={create} disabled={loading}>{loading ? 'Creating...' : 'Create'}</button>
      </div>
      {!reports.length && <div>No reports yet.</div>}
      <ul style={{ padding: 0, listStyle: 'none', display: 'grid', gap: 12 }}>
        {reports.map(r => (
          <li key={r.id} style={{ border: '1px solid #ddd', borderRadius: 8, padding: 12 }}>
            <div style={{ fontWeight: 600 }}>{r.title}</div>
            <div style={{ fontSize: 12, color: '#666' }}>{new Date(r.createdAt).toLocaleString()}</div>
            <p style={{ marginTop: 8 }}>{r.summary}</p>
            <pre style={{ background: '#f8f8f8', padding: 8, borderRadius: 6, overflowX: 'auto' }}>{JSON.stringify(r.payload, null, 2)}</pre>
          </li>
        ))}
      </ul>
    </section>
  )
}
