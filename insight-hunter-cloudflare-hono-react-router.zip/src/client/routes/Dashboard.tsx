import React from 'react'

export default function Dashboard() {
  return (
    <section>
      <h2>Dashboard</h2>
      <p>Starter fullstack on Cloudflare Workers using Hono + React Router. Add your widgets here.</p>
      <ul>
        <li>Auth via JWT (stored in localStorage)</li>
        <li>Reports History page (reads/writes KV)</li>
        <li>API routes under <code>/api/*</code></li>
      </ul>
    </section>
  )
}
