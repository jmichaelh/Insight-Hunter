import React from 'react'
import { Navigate, useLocation } from 'react-router-dom'

export default function Protected({ children }: { children: React.ReactNode }) {
  const token = localStorage.getItem('ih_jwt')
  const loc = useLocation()
  if (!token) return <Navigate to="/login" state={{ from: loc.pathname }} replace />
  return <>{children}</>
}
