# Insight Hunter Frontend (D1 compatible)
Set VITE_API_BASE to the deployed Worker URL.
