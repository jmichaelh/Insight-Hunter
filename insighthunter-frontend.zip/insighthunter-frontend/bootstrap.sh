#!/usr/bin/env bash
set -euo pipefail

echo "==> Insight Hunter Frontend bootstrap"
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "Created .env from .env.example"
fi
echo "Current .env:"
cat .env || true

echo "Run: npm install && npm run build"
