# Insight Hunter Frontend (Vite + React + TS)

## Quick Start
```bash
npm install
cp .env.example .env
# edit .env to point VITE_API_BASE at your deployed Worker URL
npm run dev
```
For Cloudflare Pages deployment, connect this repo via Git and set build:
- Build command: `npm run build`
- Output dir: `dist`
